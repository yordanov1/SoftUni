﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO
{
    public class ExportPartDto
    {
        public string Name { get; set; }

        public string Price { get; set; }
    }
}
