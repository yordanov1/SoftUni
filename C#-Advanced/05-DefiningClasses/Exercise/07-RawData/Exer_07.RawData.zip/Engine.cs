﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exer_07.RawData
{
    public class Engine
    {
        public Engine(int enginePower)
        {
            EnginePower = enginePower;
        }
        public int EnginePower { get; set; }
    }
}
